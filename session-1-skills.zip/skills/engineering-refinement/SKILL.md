---
name: engineering-refinement
description: Third skill in the spec-clarity pipeline. Breaks a gate-passed Jira ticket into buildable engineering tasks - each with a technical approach, test expectations, and references to real files/modules - so a Claude implementation session can build without guessing. Use when a developer is decomposing an approved story into tasks/subtasks, planning the technical approach for a ticket, or preparing a story for implementation. Reads the output of spec-quality-gate.
---

# Engineering Refinement

Decompose an approved spec into tasks a developer or a Claude implementation session can build directly. This is step 3 of 3: **product-refinement -> spec-quality-gate -> engineering-refinement**.

Run this with codebase access, in a developer's context. Only pick up tickets that have **passed the quality gate**.

> Asking questions: whenever this skill asks the user something, use the **AskUserQuestion** tool with concrete options - never free-form prose questions. Combine the questions for a given step into a single call and wait for the answer before continuing.

## Inputs

- The gate-passed Jira ticket and its readiness scorecard (via Jira MCP or pasted).
- The codebase, so tasks reference real files and modules.

## Workflow

```
- [ ] 1. Confirm the ticket passed the gate
- [ ] 2. Explore the codebase for affected and reusable code
- [ ] 3. Offer to fetch external context (optional)
- [ ] 4. Propose technical scope - STOP, confirm with the developer
- [ ] 5. Break into tasks - STOP, developer reviews and approves
- [ ] 6. Write the approved breakdown back to the ticket
```

### 1. Confirm the gate

If there is no passing scorecard, stop and route the ticket back through **spec-quality-gate**. Do not decompose an unvetted spec.

### 2. Explore the codebase

Find the files, components, and modules the work touches. **Actively look for existing code to reuse** rather than rewrite - flag reuse candidates explicitly. This is where decomposition most often goes wrong: tasks that invent new code parallel to something that already exists.

### 3. Offer to fetch external context (optional)

Assess whether external resources would improve the breakdown - this is a legacy-to-modern migration, so framework migration guides, library changelogs, or API docs are often relevant. Propose specific URLs or search queries and why each helps, for example:

- A React migration guide for an Angular pattern being replaced
- Release notes or a changelog for a major dependency bump
- Official docs for a new API or library being adopted

Use the **AskUserQuestion** tool to ask whether to fetch them. If they approve (or supply their own URLs), use `WebFetch` or `WebSearch` before continuing and fold the findings into the technical approach. If they decline, proceed with what you have.

### 4. Propose technical scope

Summarize the affected repos/modules, the reuse candidates from step 2, and known technical constraints. -> STOP. Use the **AskUserQuestion** tool to confirm this is right with the developer before decomposing - getting scope wrong here wastes the whole breakdown.

### 5. Break into tasks

Use `assets/task-breakdown-template.md`. Each task must:
- cite **real files/modules** (paths), not hypothetical ones;
- name a technical approach;
- state test expectations consistent with the team Definition of Done (unit + accessibility tests, coverage target - see CLAUDE.md);
- flag any reuse candidate found in step 2.

-> STOP. Share the task breakdown. Use the **AskUserQuestion** tool to confirm the file references are real, the decomposition is right-sized, and no reusable code is being needlessly rewritten. Iterate until the developer approves.

### 6. Write back

Write the approved breakdown to the ticket as subtasks (or hand back markdown). This is the final "ready for Claude" handoff - an implementation session can now build from it without guessing.

> When chaining from an upstream spec, **preserve the product and gate content exactly** - only append the engineering sections. Do not rewrite or drop what product-refinement and spec-quality-gate already established.

## What good looks like

- Every acceptance criterion maps to at least one task.
- Tasks cite real files/modules and are independently buildable.
- Reuse candidates are flagged, not silently rewritten.
- Test expectations match the Definition of Done.
- Open technical questions are genuinely open, not rhetorical.
- Scope is bounded so the work cannot balloon during implementation.
