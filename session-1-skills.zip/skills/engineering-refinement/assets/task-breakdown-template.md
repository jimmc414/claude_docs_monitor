<!-- LIGHTWEIGHT STARTER - adjust task granularity and fields with the team in session. -->

# Task Breakdown - [Ticket ID]

**Gate scorecard:** PASS (link/ref)
**Acceptance criteria covered:** AC1, AC2, AC3 (every AC should map to at least one task below)

## Reuse candidates found
Existing code to extend rather than rewrite:

- `path/to/existing/Thing.tsx` - ... (how it applies)

## Tasks

### Task 1: [short title]
- **Files/modules:** `path/to/file.tsx`, `path/to/other.ts`
- **Approach:** ...
- **Covers:** AC1
- **Tests:** unit (...); accessibility (...); per Definition of Done in CLAUDE.md
- **Notes / risks:** ...

### Task 2: [short title]
- **Files/modules:** ...
- **Approach:** ...
- **Covers:** AC2, AC3
- **Tests:** ...
- **Notes / risks:** ...

## Open technical questions
Anything to resolve before or during implementation:

- ...
