---
name: product-refinement
description: First skill in the spec-clarity pipeline. Turns a raw idea or feature request into a well-formed spec on a Jira ticket - acceptance criteria, pre/post-conditions, scope, non-goals, and an explicit Assumptions & Open Questions section. Use when a PM is refining a ticket before engineering picks it up, when a ticket is too vague to build, or when starting requirements for a new Coverity Connect UI story. Hands off to spec-quality-gate.
---

# Product Refinement

Turn an idea into a spec a developer (and Claude) can build from without guessing. This is step 1 of 3: **product-refinement -> spec-quality-gate -> engineering-refinement**.

> Asking questions: whenever this skill asks the user something, use the **AskUserQuestion** tool with concrete options - never free-form prose questions. Combine the questions for a given step into a single call and wait for the answer before continuing.

## Inputs

- The Jira ticket being refined (the source of truth). Read it via the Jira MCP if available; otherwise ask the user to paste the ticket body.
- Optional: a Figma-to-story output, if the existing Figma skill already produced one.

> If no Jira MCP is configured, produce the refined spec as markdown for the user to paste back into the ticket.

## Workflow

```
- [ ] 1. Read the ticket and any linked design/context
- [ ] 2. Establish the WHY (business drivers, intent) - STOP, ask the PM
- [ ] 3. Clarify the WHAT (requirements, scope) - STOP, ask the PM
- [ ] 4. Draft the spec into the AC template
- [ ] 5. Fill the Assumptions & Open Questions section honestly
- [ ] 6. STOP - review and approve the AC with the PM
- [ ] 7. Write the approved spec back to the ticket
```

### 1. Read the ticket

Pull the ticket and any linked Figma story or context. Note what the ticket actually asks for versus what is left unstated.

### 2. Establish the WHY

Before drafting anything, get the intent. The PM holds context the skill cannot infer: business driver, who asked for this, urgency, and what happens if it isn't done. -> STOP. Use the **AskUserQuestion** tool to ask 2-4 focused questions about *why* this work matters, and wait for the answer. Drafting AC before the WHY is clear is how specs drift from real intent.

### 3. Clarify the WHAT

With the WHY established, pin down *what* gets built: the concrete behaviors, boundaries, and any integration points. -> STOP. Use the **AskUserQuestion** tool to ask 2-4 questions about scope and specifics, and wait. Keep this product-level - the *how* belongs to engineering-refinement, not here.

### 4. Draft the spec

Use `assets/acceptance-criteria-template.md`. See `assets/ac-examples.md` for good-vs-bad pairs. Write acceptance criteria that are **testable** and phrased so both a human and an LLM read them the same way: concrete, unambiguous, one expectation per criterion. Capture in-scope, non-goals, and **scope risks** (things that could expand the work if not bounded).

### 5. Fill Assumptions & Open Questions

This section is **mandatory and never empty**. Every place you had to infer intent, fill a gap, or pick between interpretations becomes an entry here. This is the highest-value part of the skill: anything not stated is something a downstream session would otherwise guess at.

### 6. Review with the PM

-> STOP. Share the drafted AC and, especially, the Assumptions & Open Questions list. Use the **AskUserQuestion** tool to have the PM resolve each open question and confirm the criteria. Iterate with them - this is co-built, not approved blind. Do not proceed until the PM signs off.

### 7. Write back

Write the approved spec to the Jira ticket (via MCP or hand back markdown to paste). The refined ticket is the handoff artifact for **spec-quality-gate**.

## What good looks like

- The WHY is captured so someone who wasn't in the room understands the intent.
- Acceptance criteria are testable and implementation-agnostic (no technical sections - those belong in engineering-refinement).
- Scope, non-goals, and scope risks are all named.
- Assumptions & Open Questions is non-empty and the PM has resolved each.
