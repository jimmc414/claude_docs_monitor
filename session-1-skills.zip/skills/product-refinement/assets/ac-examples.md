<!-- LIGHTWEIGHT STARTER - a couple of contrasting pairs to set the bar. Add real Coverity Connect examples in session. -->

# Good vs. Bad Acceptance Criteria

The pattern: bad ACs are vague, untestable, or bundle several expectations. Good ACs are concrete, single-purpose, and verifiable.

## Example 1

BAD: "The scan results page should load quickly and look good."
- Not testable (what is "quickly"? "good"?), bundles performance and visual concerns.

GOOD:
- AC1: The scan results table renders within 2 seconds for a project with up to 5,000 defects.
- AC2: Each defect row shows severity, CWE, file path, and status, matching the Figma spec.

## Example 2

BAD: "Users can filter defects."
- Silent on which fields, multi-select behavior, empty states, persistence.

GOOD:
- AC1: User can filter the defect list by severity (multi-select) and status (single-select).
- AC2: When a filter returns no rows, an empty state with a "Clear filters" action is shown.
- AC3: Active filters persist across page reloads via the URL query string.

## Example 3 - the Assumptions habit

BAD: silently assumes the API already returns a `cwe` field.

GOOD: adds to Assumptions & Open Questions:
- OPEN QUESTION: Does the existing defects API return a `cwe` field, or does this need a backend change? (Blocks AC2.)
