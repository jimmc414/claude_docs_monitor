<!-- LIGHTWEIGHT STARTER - expect the team to adjust section names and depth in session. -->

# [Ticket title]

## Summary
One or two sentences: what we are building and why it matters to the user.

## Acceptance Criteria
Testable, one expectation each. Prefer Given/When/Then where it adds clarity.

- [ ] AC1: ...
- [ ] AC2: ...
- [ ] AC3: ...

## Preconditions
What must be true before this work begins (state, data, feature flags, access).

- ...

## Postconditions
What must be true after - the observable end state.

- ...

## Scope
In scope: ...

## Non-goals
Explicitly out of scope, so no one (human or LLM) expands the work:

- ...

## Scope risks
Things that could expand or derail scope during implementation if not bounded now:

- ...

## Assumptions & Open Questions
MANDATORY - never leave empty. Every inferred decision or gap goes here for the PM to resolve.

- [ ] ASSUMPTION: ... (confirm with PM)
- [ ] OPEN QUESTION: ...
