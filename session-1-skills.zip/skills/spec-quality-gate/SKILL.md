---
name: spec-quality-gate
description: Second skill in the spec-clarity pipeline. Independently grades a refined Jira ticket against a readiness rubric and produces an advisory scorecard - scores, gaps, and a pass/fail recommendation - before any code is written. Use in a fresh session (not the one that wrote the spec) to check whether a ticket is sufficiently specified to build, to decide if a story is ready for engineering, or to find what is missing in a spec. Reads the output of product-refinement; gates entry to engineering-refinement.
---

# Spec Quality Gate

Grade whether a spec is ready to build. This is step 2 of 3: **product-refinement -> spec-quality-gate -> engineering-refinement**.

**Run this in a fresh context, separate from the session that authored the spec.** Independence is the point - a grader that also wrote the spec will rubber-stamp it.

> Asking questions: whenever this skill asks the user something, use the **AskUserQuestion** tool with concrete options - never free-form prose questions. Wait for the answer before continuing.

## Input

The refined Jira ticket from **product-refinement** (read via Jira MCP, or ask the user to paste it). Do not pull in the authoring conversation.

## Workflow

```
- [ ] 1. Read the spec - only the ticket, nothing from the authoring session
- [ ] 2. Score every criterion in the rubric
- [ ] 3. For security-critical tickets, apply the security lens
- [ ] 4. Produce the scorecard with a pass/fail recommendation
- [ ] 5. STOP (conditional) - if FAIL, route back to product-refinement
```

### 1. Read the spec

Read the ticket as written. If something is unclear, that is a finding, not something to infer.

### 2. Score against the rubric

Use `assets/readiness-rubric.md`. Score **every** criterion explicitly - never skip one or collapse them into a gut-feel verdict. Each gets a score and a one-line justification grounded in the spec text.

### 3. Security lens (conditional)

If the ticket touches authn/authz, data exposure, input handling, or anything security-sensitive, read `references/security-review-lens.md` and apply it as additional rubric criteria.

### 4. Produce the scorecard

Fill `assets/scorecard-template.md`: per-criterion scores, a concrete gap list, and a **pass/fail recommendation**. The recommendation is advisory - the human decides. The gap list must be specific enough that the PM can act on it without rereading the rubric.

### 5. Route on the result

-> STOP. Share the scorecard, then use the **AskUserQuestion** tool to confirm how to proceed (the recommendation is advisory - the human decides):
- **FAIL or gaps:** hand the gap list back to **product-refinement** to address. The spec does not advance.
- **PASS:** the ticket is cleared for **engineering-refinement**. Attach the scorecard to the ticket as the handoff artifact.
