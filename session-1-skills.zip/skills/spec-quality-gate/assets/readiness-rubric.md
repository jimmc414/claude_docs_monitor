<!-- LIGHTWEIGHT STARTER - tune criteria, weights, and the pass threshold with the team in session. -->

# Spec Readiness Rubric

Score each criterion: 2 = fully met, 1 = partial, 0 = missing. Note one line of justification from the spec text for each.

| # | Criterion | What "met" means |
|---|-----------|------------------|
| 1 | Clear summary | A reader knows what is being built and why in one read |
| 2 | Testable acceptance criteria | Each AC is concrete and verifiable; no "quickly", "nicely", "etc." |
| 3 | One expectation per AC | No AC bundles multiple independent expectations |
| 4 | Preconditions stated | Required starting state/data/flags are explicit |
| 5 | Postconditions stated | The observable end state is explicit |
| 6 | Scope and non-goals | Both in-scope and out-of-scope are named |
| 7 | Assumptions & Open Questions resolved | Section exists and has no unresolved blockers |
| 8 | No silent dependencies | API/data/design dependencies are named, not assumed |

## Recommendation

- **PASS** recommended when criteria 1-7 are all >= 1 AND criteria 2 and 7 are 2, with no unresolved blocker in Assumptions & Open Questions.
- Otherwise **FAIL** - return to product-refinement with the gap list.

(Threshold is a starting point - calibrate against real tickets.)
