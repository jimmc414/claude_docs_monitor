<!-- LIGHTWEIGHT STARTER - adjust the shape to whatever the team wants attached to the ticket. -->

# Readiness Scorecard - [Ticket ID]

**Recommendation: PASS | FAIL**
**Score: [sum] / 16**

## Per-criterion

| # | Criterion | Score | Justification |
|---|-----------|:-----:|---------------|
| 1 | Clear summary | _/2 | ... |
| 2 | Testable acceptance criteria | _/2 | ... |
| 3 | One expectation per AC | _/2 | ... |
| 4 | Preconditions stated | _/2 | ... |
| 5 | Postconditions stated | _/2 | ... |
| 6 | Scope and non-goals | _/2 | ... |
| 7 | Assumptions resolved | _/2 | ... |
| 8 | No silent dependencies | _/2 | ... |

## Gaps to address
Specific and actionable - the PM should be able to act on each without rereading the rubric.

- [ ] ...

## Security lens applied?
Yes / No - if yes, summarize findings.
