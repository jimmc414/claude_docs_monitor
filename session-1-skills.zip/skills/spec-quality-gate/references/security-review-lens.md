<!-- LIGHTWEIGHT STARTER - JP flagged security as critical. Expand with Black Duck's own security requirements in session. -->

# Security Review Lens

Apply these as additional rubric criteria when a ticket touches authentication, authorization, data exposure, input handling, or any security-sensitive surface. Each should be scored like the main rubric (2/1/0).

- **Authorization explicit:** the spec states who may perform the action and what happens on unauthorized access.
- **Sensitive data handled:** any PII, secrets, or scan/defect data that is sensitive is identified, with handling/redaction stated.
- **Input validation:** untrusted input (user fields, query params, uploads) has stated validation/escaping expectations.
- **Error/leakage behavior:** error states do not expose internal details (stack traces, internal IDs, defect data the user should not see).
- **Audit/logging:** if the action is security-relevant, the spec says what is logged.

If any of these is relevant but unaddressed, it is a gap - record it in the scorecard and recommend FAIL until resolved.
